﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Claims;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading;

namespace HelloImpersonationWCFApplication
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public Service1()
        {
            Console.WriteLine("Service object created: " + this.GetHashCode().ToString());
        }

        ~Service1()
        {
            Console.WriteLine("Service object destroyed: " + this.GetHashCode().ToString());
        }
        
        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public string GetData(int value)
        {
            //ClaimsPrincipal claim = Thread.CurrentPrincipal.Identity as ClaimsPrincipal;
            Console.WriteLine("Called by {0}", Thread.CurrentPrincipal.Identity.Name);
            Console.WriteLine("IsAuthenticated: {0}", Thread.CurrentPrincipal.Identity.IsAuthenticated.ToString());
            Console.WriteLine("AuthenticationType: {0}", Thread.CurrentPrincipal.Identity.AuthenticationType.ToString());
            return string.Format("You entered: {0}", value);
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            //ClaimsPrincipal claim = Thread.CurrentPrincipal.Identity as ClaimsPrincipal;
            Console.WriteLine("Called by {0}", Thread.CurrentPrincipal.Identity.IsAuthenticated.ToString());
            Console.WriteLine("IsAuthenticated: {0}", Thread.CurrentPrincipal.Identity.IsAuthenticated.ToString());
            Console.WriteLine("AuthenticationType: {0}", Thread.CurrentPrincipal.Identity.AuthenticationType.ToString());

            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
