﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;


// Ref MSDN: https://docs.microsoft.com/en-us/dotnet/framework/wcf/feature-details/how-to-create-a-duplex-contract
namespace Microsoft.ServiceModel.Samples
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri baseAddress = new Uri("http://localhost:8000/servicemodelsamples/duplexservice");
            using (ServiceHost serviceHost = new ServiceHost(typeof(CalculatorService),baseAddress))
            {
                serviceHost.AddServiceEndpoint(typeof(ICalculatorDuplex), new WSDualHttpBinding(), "");
                ServiceMetadataBehavior smb = serviceHost.Description.Behaviors.Find<ServiceMetadataBehavior>();
                if (smb == null)
                {
                    smb = new ServiceMetadataBehavior();
                    smb.HttpGetEnabled = true;
                    serviceHost.Description.Behaviors.Add(smb);
                }

                // Open the ServiceHostBase to create listeners and start listening for messages.  
                serviceHost.Open();

                // The service can now be accessed.  
                Console.WriteLine("The service is ready.");
                Console.WriteLine("Press <ENTER> to terminate service.");
                Console.WriteLine();
                Console.ReadLine();
            }
        }

        [ServiceContract(Namespace = "http://Microsoft.ServiceModel.Samples", SessionMode = SessionMode.Required,
                         CallbackContract = typeof(ICalculatorDuplexCallback))]
        public interface ICalculatorDuplex
        {
            [OperationContract(IsOneWay = true)]
            void Clear();
            [OperationContract(IsOneWay = true)]
            void AddTo(double n);
            [OperationContract(IsOneWay = true)]
            void SubtractFrom(double n);
            [OperationContract(IsOneWay = true)]
            void MultiplyBy(double n);
            [OperationContract(IsOneWay = true)]
            void DivideBy(double n);
        }

        public interface ICalculatorDuplexCallback
        {
            [OperationContract(IsOneWay = true)]
            void Equals(double result);
            [OperationContract(IsOneWay = true)]
            void Equation(string eqn);
        }

        [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
        public class CalculatorService : ICalculatorDuplex
        {
            double result;
            string equation;
            ICalculatorDuplexCallback callback = null;

            public CalculatorService()
            {
                result = 0.0D;
                equation = result.ToString();
                callback = OperationContext.Current.GetCallbackChannel<ICalculatorDuplexCallback>();
            }

            public void Clear()
            {
                callback.Equation(equation + " = " + result.ToString());
                result = 0.0D;
                equation = result.ToString();
            }

            public void AddTo(double n)
            {
                result += n;
                equation += " + " + n.ToString();
                callback.Equals(result);
            }

            public void SubtractFrom(double n)
            {
                result -= n;
                equation += " - " + n.ToString();
                callback.Equals(result);
            }

            public void MultiplyBy(double n)
            {
                result *= n;
                equation += " * " + n.ToString();
                callback.Equals(result);
            }

            public void DivideBy(double n)
            {
                result /= n;
                equation += " / " + n.ToString();
                callback.Equals(result);
            }

        }
    }
}
