﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Microsoft.ServiceModel.Samples.ServiceReference1;



// Ref MSDN: https://docs.microsoft.com/en-us/dotnet/framework/wcf/feature-details/how-to-access-services-with-a-duplex-contract
namespace Microsoft.ServiceModel.Samples
{
    public class client
    {
        public static void Main(string[] args)
        {
            CalculatorDuplexClient wcfClient = null;
            try
            {
                wcfClient = new CalculatorDuplexClient(new InstanceContext(new CallbackHandler()));
                // Call the AddTo service operation.
                double value = 100.00D;
                wcfClient.AddTo(value);

                // Call the SubtractFrom service operation.
                value = 50.00D;
                wcfClient.SubtractFrom(value);

                // Call the MultiplyBy service operation.
                value = 17.65D;
                wcfClient.MultiplyBy(value);

                // Call the DivideBy service operation.
                value = 2.00D;
                wcfClient.DivideBy(value);

                // Complete equation.
                wcfClient.Clear();

                // Wait for callback messages to complete before
                // closing.
                System.Threading.Thread.Sleep(5000);

                // Close the WCF client.
                wcfClient.Close();
                Console.WriteLine("Done!");
                Console.Read();
            }
            catch (TimeoutException timeProblem)
            {
                Console.WriteLine("The service operation timed out. " + timeProblem.Message);
                wcfClient.Abort();
                Console.Read();
            }
            catch (CommunicationException commProblem)
            {
                Console.WriteLine("There was a communication problem. " + commProblem.Message);
                wcfClient.Abort();
                Console.Read();
            }

        }
    }

    public class CallbackHandler : ICalculatorDuplexCallback
    {
        public void Equals(double result)
        {
            Console.WriteLine("Result ({0})", result);
        }
        public void Equation(string equation)
        {
            Console.WriteLine("Equation({0})", equation);
        }
    }
}
